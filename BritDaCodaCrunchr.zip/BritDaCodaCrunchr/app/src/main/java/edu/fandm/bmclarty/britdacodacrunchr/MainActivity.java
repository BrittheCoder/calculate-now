package edu.fandm.bmclarty.britdacodacrunchr;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btnac, btnc, btn1, btn2, btnsin,btnmul,btnmin,btnhistory, btnplus,btnpi,btndot, btnequal, btncos, btntan, btnlog, btnln, btnfact, btnsquare, btnsqrt,
            btninv, btndiv, btn7, btn8, btn9, btn4, btn5, btn6, right_bracket, left_bracket, btn3, btn0, btnexpo;
    TextView row, col ;

    List<String> calculationHistory = new ArrayList<>();

    String pi = "3.141592653589793";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        row=findViewById(R.id.row);
        col=findViewById(R.id.col);

        btnac=findViewById(R.id.btnac);
        btnc=findViewById(R.id.btnc);
        btn0=findViewById(R.id.btn0);
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);

        btnsin=findViewById(R.id.btnsin);
        btnmul=findViewById(R.id.btnmul);
        btnmin=findViewById(R.id.btnmin);
        btnplus=findViewById(R.id.btnplus);
        btnpi=findViewById(R.id.btnpi);
        btndot=findViewById(R.id.btndot);
        btnequal=findViewById(R.id.btnequal);

        btncos=findViewById(R.id.btncos);
        btntan=findViewById(R.id.btntan);
        btnlog=findViewById(R.id.btnlog);
        btnln=findViewById(R.id.btnln);

        btnfact=findViewById(R.id.btnfact);
        btnsquare=findViewById(R.id.btnsquare);
        btnsqrt=findViewById(R.id.btnsqrt);
        btninv=findViewById(R.id.btninv);
        btndiv=findViewById(R.id.btndiv);
        btnexpo=findViewById(R.id.btnexpo);

        btn6=findViewById(R.id.btn6);
        btn7=findViewById(R.id.btn7);
        btn8=findViewById(R.id.btn8);
        btn9=findViewById(R.id.btn9);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);



        left_bracket=findViewById(R.id.left_bracket);
        right_bracket=findViewById(R.id.right_bracket);
        btnhistory=findViewById(R.id.btnhistory);

        //onclick listeners learnt in class
        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"0");
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"(");
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {col.setText(col.getText()+")");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"4");
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {col.setText(col.getText()+"8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"9");
            }
        });
        btnac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText("");
                row.setText("");
            }
        });
        btndot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+".");
            }
        });

        btnc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val = col.getText().toString();
                val = val.substring(0, val.length() - 1);
                col.setText(val);
            }
        });
        btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"+");
            }
        });
        btnmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"-");
            }
        });
        btnmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"×");
            }
        });
        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"÷");
            }
        });
        btnsqrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = col.getText().toString();
                double d = Math.sqrt(Double.parseDouble(number));
                col.setText(String.valueOf(d));
            }
        });
        left_bracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"1");
            }
        });
        right_bracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"2");
            }
        });
        btnpi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                row.setText(btnpi.getText());
                col.setText(col.getText()+pi);
            }
        });
        btnsin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {col.setText(col.getText()+"sin");
            }
        });
        btnexpo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {col.setText(col.getText()+"^");
            }
        });
        btncos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"cos");
            }
        });
        btntan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"tan");
            }
        });
        btninv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"^"+"(-1)");
            }
        });
        btnfact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num = Integer.parseInt(col.getText().toString());
                int fac = factorial(num);
                col.setText(String.valueOf(fac));
                row.setText(num+"!");
            }
        });

        //setting the on click listener to the id of btn square
        btnsquare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //gets the text from the col converts it to a double and then store it
                double d = Double.parseDouble(col.getText().toString());
                double square = d*d;
                col.setText(String.valueOf(square));
                row.setText(d+"²");
            }
        });
        btnln.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {col.setText(col.getText()+"ln");
            }
        });
        btnlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                col.setText(col.getText()+"log");
            }
        });

        //chatgpt

        btnhistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btnHistory = findViewById(R.id.btnhistory);
                if (calculationHistory.isEmpty()){
                    btnHistory.setEnabled(false);
                }else{
                    btnHistory.setEnabled(true);
                }
                col.setText(col.getText()+"History");
            }
        });

        btnhistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showHistory();
            }
        });

        btnequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //retrieve the value then store it in val
                String val = col.getText().toString();
                //this is where we replace one symbol with the other, evaluating math expressions
                String replace = val.replace('÷','/').replace('×','*');
                //calls eval then changes the string replace as an argument
                double result = eval(replace);
                //converting the result to a string
                calculationHistory.add(val+ "=" + result);
                col.setText(String.valueOf(result));
                row.setText(val);
            }
        });

    }
    public void showHistory(){
        StringBuilder historyText = new StringBuilder();
        for(String calculation: calculationHistory){
            historyText.append(calculation).append("\n");
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("History");
        builder.setMessage(historyText.toString());
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    int factorial(int n) //factorial formula n!= n*(n-1)*...*1 //found on google
    {
        return (n==1 || n==0) ? 1 : n*factorial(n-1);
    }

    //eval function - takes a string as an input which shows an expression...
    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean tf(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            //this starts the parsing by calling parse expression..
            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
                return x;
            }

            //this function is responsible for subtraction n addition
            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if      (tf('+')) x += parseTerm(); // addition
                    else if (tf('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            //this function is responsible for division multiplication
            double parseTerm() {
                double x = parseFact();
                for (;;) {
                    if      (tf('*')) x *= parseFact(); // multiplication application
                    else if (tf('/')) x /= parseFact(); // division
                    else return x;
                }
            }

            double parseFact() {
                if (tf('+')) return parseFact();
                if (tf('-')) return -parseFact();

                double x;

                int startPos = this.pos;
                if (tf('(')) { // parentheses
                    x = parseExpression();
                    tf(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers

                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();

                    x = Double.parseDouble(str.substring(startPos, this.pos));

                } else if (ch >= 'a' && ch <= 'z') { // functions

                    while (ch >= 'a' && ch <= 'z') nextChar();

                    String func = str.substring(startPos, this.pos);

                    x = parseFact();

                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x)); //for sin, cos and tan we need radians
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else if (func.equals("log")) x = Math.log10(x);
                    else if (func.equals("ln")) x = Math.log(x); //for example log3 10
                    else throw new RuntimeException("Unknown function: " + func);
                    //error message if there is a unexpected character value entered.
                } else {
                    throw new RuntimeException("Unexpected: " + (char)ch);
                }

                if (tf('^')) x = Math.pow(x, parseFact()); // exponentiation

                return x;
            }
        }.parse();
    }
}

// use for buttons on history array-- https://chat.openai.com/share/7790b1cd-c39c-4de1-810c-b220f50fa16f